jQuery(document).ready(function($) {
    $('.main-navigation .menu > li').hover(
        function() {
            $(this).children('ul').stop(true, true).slideDown(200);
        },
        function() {
            $(this).children('ul').stop(true, true).slideUp(200);
        }
    );
});
