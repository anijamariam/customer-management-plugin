<?php
/*
Template Name: Login Page
*/
get_header();
?>
<div class="page-content">
    <?php echo do_shortcode('[customer_login]'); ?>
</div>
<?php get_footer(); ?>