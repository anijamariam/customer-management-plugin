<?php

// Enqueue styles and scripts
function custom_theme_enqueue_styles_scripts() {
    // Enqueue the main stylesheet
    wp_enqueue_style('custom-theme-style', get_template_directory_uri() . '/style.css');
    
    // Enqueue jQuery
    wp_enqueue_script('jquery');
}
add_action('wp_enqueue_scripts', 'custom_theme_enqueue_styles_scripts');

// Register navigation menu
function register_my_menus() {
    register_nav_menus(
        array(
            'primary' => __( 'Primary Menu' )
        )
    );
}
add_action('init', 'register_my_menus');

// Helper function to create a dynamic menu item
function create_dynamic_menu_item($title, $url) {
    return (object) array(
        'ID' => 0,
        'db_id' => 0,
        'menu_item_parent' => 0,
        'object_id' => 0,
        'object' => '',
        'type' => 'custom',
        'type_label' => 'Custom',
        'title' => $title,
        'url' => $url,
        'target' => '',
        'attr_title' => '',
        'description' => '',
        'classes' => array('menu-item'),
        'xfn' => '',
        'status' => '',
        'current' => false,
        'current_item_ancestor' => false,
        'current_item_parent' => false,
    );
}

// Add dynamic menu items
function add_dynamic_menu_items($items, $args) {
    if ($args->theme_location == 'primary') {
        if (is_user_logged_in()) {
            $logout_url = wp_logout_url(home_url());
            $items = array(create_dynamic_menu_item('Logout', esc_url($logout_url)));
        } else {
            // Fetch the URLs for the login and signup pages dynamically
            $login_page = get_page_by_path('customer-login');
            $signup_page = get_page_by_path('customer-signup');

            $login_page_url = $login_page ? get_permalink($login_page->ID) : '';
            $signup_page_url = $signup_page ? get_permalink($signup_page->ID) : '';

            if ($login_page_url) {
                $items[] = create_dynamic_menu_item('Login Page', esc_url($login_page_url));
            }
            if ($signup_page_url) {
                $items[] = create_dynamic_menu_item('Sign Up', esc_url($signup_page_url));
            }
        }
    }
    return $items;
}
add_filter('wp_nav_menu_objects', 'add_dynamic_menu_items', 10, 2);

// Redirect to welcome page after login for non-admin users
function custom_login_redirect($redirect_to, $request, $user) {
    if (is_wp_error($user) || empty($user)) {
        error_log("No valid user object found.");
        return $redirect_to;
    }

    // Ensure $user is a WP_User object
    if (!($user instanceof WP_User)) {
        error_log("The user is not an instance of WP_User.");
        return $redirect_to;
    }

    // Check if there is a user to check
    if (isset($user->roles) && is_array($user->roles)) {
        // Check if the user is an admin
        if (in_array('administrator', $user->roles)) {
            error_log("User is an admin. Redirecting to admin dashboard.");
            return admin_url(); // Redirect admins to the admin dashboard
        } else {
            // Get the Welcome page for non-admin users
            $welcome_page = get_page_by_path('welcome');
            if ($welcome_page) {
                $welcome_url = get_permalink($welcome_page->ID);
                error_log("User is not an admin. Redirecting to: " . $welcome_url); // Debugging line
                return $welcome_url;
            } else {
                error_log("Welcome page not found."); // Debugging line
            }
        }
    } else {
        error_log("No user roles found."); // Debugging line
    }
    error_log("Returning default redirect URL: " . $redirect_to); // Debugging line
    return $redirect_to;
}
add_filter('login_redirect', 'custom_login_redirect', 10, 3);


?>
