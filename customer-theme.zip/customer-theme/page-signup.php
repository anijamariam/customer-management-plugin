<?php
/*
Template Name: Signup Page
*/
get_header();
?>
<div class="page-content">
    <?php echo do_shortcode('[customer_signup]'); ?>
</div>
<?php get_footer(); ?>