</main>
    <footer class="site-footer">
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> Customer Management</p>
        </div>
    </footer>
    <?php wp_footer(); ?>
</body>
</html>
