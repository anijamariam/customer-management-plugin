<div class="wrap">
    <h1>Add New Customer</h1>
    <form method="post" action="">
        <input type="hidden" name="action" value="add_customer">
        <?php wp_nonce_field('add_customer_nonce'); ?>
        <table class="form-table">
            <tr>
                <th><label for="name">Name</label></th>
                <td><input type="text" name="name" id="name" required></td>
            </tr>
            <tr>
                <th><label for="email">Email</label></th>
                <td><input type="email" name="email" id="email" required></td>
            </tr>
            <tr>
                <th><label for="phone">Phone</label></th>
                <td><input type="text" name="phone" id="phone" required></td>
            </tr>
            <tr>
                <th><label for="dob">Date of Birth</label></th>
                <td><input type="date" name="dob" id="dob" required></td>
            </tr>
            <tr>
                <th><label for="gender">Gender</label></th>
                <td>
                    <select name="gender" id="gender">
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><label for="cr_number">CR Number</label></th>
                <td><input type="text" name="cr_number" id="cr_number" required></td>
            </tr>
            <tr>
                <th><label for="address">Address</label></th>
                <td><textarea name="address" id="address" required></textarea></td>
            </tr>
            <tr>
                <th><label for="city">City</label></th>
                <td><input type="text" name="city" id="city" required></td>
            </tr>
            <tr>
                <th><label for="country">Country</label></th>
                <td><input type="text" name="country" id="country" required></td>
            </tr>
            <tr>
                <th><label for="status">Status</label></th>
                <td>
                    <select name="status" id="status">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                    </select>
                </td>
            </tr>
        </table>
        <p class="submit">
            <button type="submit" class="button-primary">Add Customer</button>
        </p>
    </form>
</div>
