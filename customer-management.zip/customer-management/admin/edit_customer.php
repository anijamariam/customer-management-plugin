<div class="wrap">
    <h1>Edit Customer</h1>
    <?php
    $customer = (new CustomerManagementPlugin())->get_customer($_GET['id']);
    if ($customer) {
    ?>
    <form method="post" action="">
        <input type="hidden" name="action" value="edit_customer">
        <input type="hidden" name="id" value="<?php echo $customer->id; ?>">
        <?php wp_nonce_field('edit_customer_nonce'); ?>
        <table class="form-table">
            <tr>
                <th><label for="name">Name</label></th>
                <td><input type="text" name="name" id="name" value="<?php echo $customer->name; ?>" required></td>
            </tr>
            <tr>
                <th><label for="email">Email</label></th>
                <td><input type="email" name="email" id="email" value="<?php echo $customer->email; ?>" required></td>
            </tr>
            <tr>
                <th><label for="phone">Phone</label></th>
                <td><input type="text" name="phone" id="phone" value="<?php echo $customer->phone; ?>" required></td>
            </tr>
            <tr>
                <th><label for="dob">Date of Birth</label></th>
                <td><input type="date" name="dob" id="dob" value="<?php echo $customer->dob; ?>" required></td>
            </tr>
            <tr>
                <th><label for="gender">Gender</label></th>
                <td>
                    <select name="gender" id="gender">
                        <option value="Male" <?php selected($customer->gender, 'Male'); ?>>Male</option>
                        <option value="Female" <?php selected($customer->gender, 'Female'); ?>>Female</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th><label for="cr_number">CR Number</label></th>
                <td><input type="text" name="cr_number" id="cr_number" value="<?php echo $customer->cr_number; ?>" required></td>
            </tr>
            <tr>
                <th><label for="address">Address</label></th>
                <td><textarea name="address" id="address" required><?php echo $customer->address; ?></textarea></td>
            </tr>
            <tr>
                <th><label for="city">City</label></th>
                <td><input type="text" name="city" id="city" value="<?php echo $customer->city; ?>" required></td>
            </tr>
            <tr>
                <th><label for="country">Country</label></th>
                <td><input type="text" name="country" id="country" value="<?php echo $customer->country; ?>" required></td>
            </tr>
            <tr>
                <th><label for="status">Status</label></th>
                <td>
                    <select name="status" id="status">
                        <option value="active" <?php selected($customer->status, 'active'); ?>>Active</option>
                        <option value="inactive" <?php selected($customer->status, 'inactive'); ?>>Inactive</option>
                    </select>
                </td>
            </tr>
        </table>
        <p class="submit">
            <button type="submit" class="button-primary">Update Customer</button>
        </p>
    </form>
    <?php
    } else {
        echo '<p>Customer not found.</p>';
    }
    ?>
</div>
