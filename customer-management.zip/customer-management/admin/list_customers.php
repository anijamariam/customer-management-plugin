<div class="wrap">
    <h1>Customer Management</h1>
    <a href="?page=customer-management&action=add" class="page-title-action">Add New</a>
    <form method="get" style="margin-top: 20px;">
        <input type="hidden" name="page" value="customer-management">
        <input type="text" name="s" placeholder="Search customers..." value="<?php echo isset($_GET['s']) ? esc_attr($_GET['s']) : ''; ?>">
        <button type="submit" class="button">Search</button>
    </form>

    <?php
    $customers_per_page = 3;
    $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $offset = ($current_page - 1) * $customers_per_page;
    $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';

    $customers = $this->search_customers($search, $customers_per_page, $offset);
    $total_customers = $this->get_customers_count($search);
    $total_pages = ceil($total_customers / $customers_per_page);

    if ($customers) :
    ?>
        <table class="wp-list-table widefat fixed striped" style="margin-top: 20px;">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Date of Birth</th>
                    <th>Gender</th>
                    <th>CR Number</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>Country</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($customers as $customer) : ?>
                    <tr>
                        <td><?php echo esc_html($customer->name); ?></td>
                        <td><?php echo esc_html($customer->email); ?></td>
                        <td><?php echo esc_html($customer->phone); ?></td>
                        <td><?php echo esc_html($customer->dob); ?></td>
                        <td><?php echo esc_html($customer->gender); ?></td>
                        <td><?php echo esc_html($customer->cr_number); ?></td>
                        <td><?php echo esc_html($customer->address); ?></td>
                        <td><?php echo esc_html($customer->city); ?></td>
                        <td><?php echo esc_html($customer->country); ?></td>
                        <td><?php echo esc_html($customer->status); ?></td>
                        <td>
                            <a href="?page=customer-management&action=edit&id=<?php echo esc_attr($customer->id); ?>">Edit</a> |
                            <a href="?page=customer-management&action=delete&id=<?php echo esc_attr($customer->id); ?>" onclick="return confirm('Are you sure you want to delete this customer?');">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php
            $pagination_base = add_query_arg(['paged' => '%#%', 's' => urlencode($search)], admin_url('admin.php?page=customer-management'));
            echo paginate_links([
                'base' => $pagination_base,
                'format' => '',
                'current' => $current_page,
                'total' => $total_pages,
                'prev_text' => __('&laquo; Previous'),
                'next_text' => __('Next &raquo;'),
            ]);
            ?>
        </div>
    <?php else : ?>
        <p>No customers found.</p>
    <?php endif; ?>
</div>