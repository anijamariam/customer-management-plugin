<?php
/*
Plugin Name: Customer Management
Description: A plugin to manage customer information.
Version: 1.0
Author: Anija Mariam John
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class CustomerManagementPlugin {
    public function __construct() {
        register_activation_hook(__FILE__, [$this, 'activate']);
        add_action('admin_menu', [$this, 'create_admin_menu']);
        add_shortcode('display_customers', [$this, 'display_customers_shortcode']);
        add_shortcode('customer_signup', [$this, 'customer_signup_shortcode']);
        add_shortcode('customer_login', [$this, 'customer_login_shortcode']);
        add_action('init', [$this, 'handle_form_submissions']);
        add_action('admin_notices', [$this, 'admin_notices']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
    }

    public function activate() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'customers';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name varchar(255) NOT NULL,
            email varchar(255) NOT NULL,
            phone varchar(15) NOT NULL,
            dob date NOT NULL,
            gender varchar(10) NOT NULL,
            cr_number varchar(20) NOT NULL,
            address text NOT NULL,
            city varchar(100) NOT NULL,
            country varchar(100) NOT NULL,
            status varchar(10) NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public function create_admin_menu() {
        add_menu_page(
            'Customer Management',
            'Customer Management',
            'manage_options',
            'customer-management',
            [$this, 'admin_page'],
            'dashicons-admin-users'
        );
    }

    public function admin_page() {
        if (isset($_GET['action']) && $_GET['action'] == 'add') {
            include plugin_dir_path(__FILE__) . 'admin/add_customer.php';
        } elseif (isset($_GET['action']) && $_GET['action'] == 'edit') {
            include plugin_dir_path(__FILE__) . 'admin/edit_customer.php';
        } elseif (isset($_GET['action']) && $_GET['action'] == 'delete') {
            $this->delete_customer(intval($_GET['id']));
            wp_redirect(admin_url('admin.php?page=customer-management'));
            exit;
        } else {
            include plugin_dir_path(__FILE__) . 'admin/list_customers.php';
        }
    }

    public function display_customers_shortcode() {
        ob_start();
        $this->display_customers_template();
        return ob_get_clean();
    }

    public function display_customers_template() {
        include plugin_dir_path(__FILE__) . 'templates/customer-list.php';
    }

    public function customer_signup_shortcode() {
        ob_start();
        include plugin_dir_path(__FILE__) . 'templates/customer-signup.php';
        return ob_get_clean();
    }

    public function customer_login_shortcode() {
        ob_start();
        include plugin_dir_path(__FILE__) . 'templates/customer-login.php';
        return ob_get_clean();
    }

    public function handle_form_submissions() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if (isset($_POST['action']) && $_POST['action'] == 'add_customer' && check_admin_referer('add_customer_nonce')) {
                $this->add_customer($_POST);
            }

            if (isset($_POST['action']) && $_POST['action'] == 'edit_customer' && check_admin_referer('edit_customer_nonce')) {
                $this->edit_customer($_POST['id'], $_POST);
            }

            if (isset($_POST['customer_signup']) && check_admin_referer('customer_signup_nonce')) {
                $this->process_customer_signup($_POST);
            }

            if (isset($_POST['customer_login']) && check_admin_referer('customer_login_nonce')) {
                $this->process_customer_login($_POST);
            }
        }
    }

    public function process_customer_signup($data) {
        if (email_exists($data['email'])) {
            $message = 'Email already exists.';
            wp_redirect(add_query_arg('message', urlencode($message), $_SERVER['HTTP_REFERER']));
            exit;
        }

        // Add customer to custom table
        global $wpdb;
        $table_name = $wpdb->prefix . 'customers';
        $wpdb->insert($table_name, [
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'dob' => $data['dob'],
            'gender' => $data['gender'],
            'cr_number' => $data['cr_number'],
            'address' => $data['address'],
            'city' => $data['city'],
            'country' => $data['country'],
            'status' => $data['status']
        ]);

        // Create WordPress user with the role of contributor using phone number as password
        $user_id = wp_create_user($data['email'], $data['phone'], $data['email']);
        if (is_wp_error($user_id)) {
            $message = 'Failed to create WordPress user: ' . $user_id->get_error_message();
            wp_redirect(add_query_arg('message', urlencode($message), $_SERVER['HTTP_REFERER']));
            exit;
        } else {
            $user = new WP_User($user_id);
            $user->set_role('contributor');
            $message = 'Customer added successfully.';
            wp_redirect(add_query_arg('message', urlencode($message), $_SERVER['HTTP_REFERER']));
            exit;
        }
    }

    public function process_customer_login($data) {
        $creds = array(
            'user_login' => $data['email'],
            'user_password' => $data['password'],
            'remember' => true,
        );

        $user = wp_signon($creds, false);

        if (is_wp_error($user)) {
            $message = 'Login failed: ' . $user->get_error_message();
            wp_redirect(add_query_arg('message', urlencode($message), $_SERVER['HTTP_REFERER']));
            exit;
        } else {
            wp_redirect(home_url('/welcome')); // Replace with the URL of your welcome page
            exit;
        }
    }

    public function add_customer($data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'customers';

        if (email_exists($data['email'])) {
            set_transient('customer_message', 'Email already exists.', 30);
            error_log('Email already exists: ' . $data['email']);
            return;
        }

        $result = $wpdb->insert($table_name, [
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'dob' => $data['dob'],
            'gender' => $data['gender'],
            'cr_number' => $data['cr_number'],
            'address' => $data['address'],
            'city' => $data['city'],
            'country' => $data['country'],
            'status' => $data['status']
        ]);

        if ($result === false) {
            set_transient('customer_message', 'Failed to add customer.', 30);
            error_log('Failed to insert customer: ' . $wpdb->last_error);
            return;
        }

        error_log('Customer inserted with ID: ' . $wpdb->insert_id);

        // Create WordPress user with the role of contributor using phone number as password
        $user_id = wp_create_user($data['email'], $data['phone'], $data['email']);
        if (is_wp_error($user_id)) {
            set_transient('customer_message', 'Failed to create WordPress user: ' . $user_id->get_error_message(), 30);
            error_log('Failed to create WordPress user: ' . $user_id->get_error_message());
        } else {
            $user = new WP_User($user_id);
            $user->set_role('contributor');
            error_log('WordPress user created with ID: ' . $user_id);
            set_transient('customer_message', 'Customer added successfully.', 30);
        }
    }

    public function edit_customer($id, $data) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'customers';

        $wpdb->update($table_name, [
            'name' => $data['name'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'dob' => $data['dob'],
            'gender' => $data['gender'],
            'cr_number' => $data['cr_number'],
            'address' => $data['address'],
            'city' => $data['city'],
            'country' => $data['country'],
            'status' => $data['status']
        ], ['id' => intval($id)]);
    }

    public function delete_customer($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'customers';

        $wpdb->delete($table_name, ['id' => intval($id)]);
    }

    public function get_customer($id) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'customers';

        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", intval($id)));
    }

    public function get_all_customers($limit = 10, $offset = 0) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'customers';

        $query = $wpdb->prepare("SELECT * FROM $table_name LIMIT %d OFFSET %d", $limit, $offset);
        return $wpdb->get_results($query);
    }

    public function search_customers($search = '', $limit = 10, $offset = 0) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'customers';

        if ($search) {
            $search = '%' . $wpdb->esc_like($search) . '%';
            $query = $wpdb->prepare(
                "SELECT * FROM $table_name 
                 WHERE name LIKE %s OR email LIKE %s OR phone LIKE %s OR city LIKE %s 
                 ORDER BY id DESC
                 LIMIT %d OFFSET %d",
                $search, $search, $search, $search, $limit, $offset
            );
        } else {
            $query = $wpdb->prepare(
                "SELECT * FROM $table_name 
                 ORDER BY id DESC 
                 LIMIT %d OFFSET %d", 
                $limit, $offset
            );
        }

        return $wpdb->get_results($query);
    }

    public function get_customers_count($search = '') {
        global $wpdb;
        $table_name = $wpdb->prefix . 'customers';

        if ($search) {
            $search = '%' . $wpdb->esc_like($search) . '%';
            $query = $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_name 
                 WHERE name LIKE %s OR email LIKE %s OR phone LIKE %s OR city LIKE %s",
                $search, $search, $search, $search
            );
        } else {
            $query = "SELECT COUNT(*) FROM $table_name";
        }

        return $wpdb->get_var($query);
    }

    public function admin_notices() {
        if ($message = get_transient('customer_message')) {
            echo '<div class="notice notice-success is-dismissible"><p>' . esc_html($message) . '</p></div>';
            delete_transient('customer_message');
        }
    }

    public function enqueue_scripts() {
        wp_enqueue_style('customer-management-style', plugin_dir_url(__FILE__) . 'assets/css/style.css');
    }

    public function enqueue_admin_scripts() {
        wp_enqueue_style('customer-management-admin-style', plugin_dir_url(__FILE__) . 'assets/css/admin-style.css');
    }
}

// Instantiate the plugin class
new CustomerManagementPlugin();
?>
