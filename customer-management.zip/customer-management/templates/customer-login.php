<div class="customer-login-form">
    <?php if (isset($_GET['message'])): ?>
        <div class="message"><?php echo wp_kses_post(urldecode($_GET['message'])); ?></div>
    <?php endif; ?>
    <form method="post" action="">
        <?php wp_nonce_field('customer_login_nonce'); ?>
        <table>
            <tr>
                <th><label for="email">Email</label></th>
                <td><input type="email" name="email" id="email" required></td>
            </tr>
            <tr>
                <th><label for="password">Password</label></th>
                <td><input type="password" name="password" id="password" required></td>
            </tr>
        </table>
        <p>
            <button type="submit" name="customer_login" class="button-primary">Login</button>
        </p>
    </form>
</div>
