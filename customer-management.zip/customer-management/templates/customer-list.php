<div class="customer-list">
    <?php
    $customers = (new CustomerManagementPlugin())->get_all_customers();
    foreach ($customers as $customer) {
        echo '<div class="customer">';
        echo '<h2>' . esc_html($customer->name) . '</h2>';
        echo '<p>Email: ' . esc_html($customer->email) . '</p>';
        echo '<p>Phone: ' . esc_html($customer->phone) . '</p>';
        echo '<p>Address: ' . esc_html($customer->address) . ', ' . esc_html($customer->city) . ', ' . esc_html($customer->country) . '</p>';
        echo '<p>Status: ' . esc_html($customer->status) . '</p>';
        echo '</div>';
    }
    ?>
</div>
